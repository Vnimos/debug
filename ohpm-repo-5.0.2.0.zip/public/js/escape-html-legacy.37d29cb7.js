System.register(["./@intlify-legacy.fe63d424.js"],(function(e,t){"use strict";var r;return{setters:[function(e){r=e.g}],execute:function(){
/*!
       * escape-html
       * Copyright(c) 2012-2013 TJ Holowaychuk
       * Copyright(c) 2015 Andreas Lubbe
       * Copyright(c) 2015 Tiancheng "Timothy" Gu
       * MIT Licensed
       */
var t=/["'&<>]/;e("e",r((function(e){var r,a=""+e,n=t.exec(a);if(!n)return a;var s="",c=0,i=0;for(c=n.index;c<a.length;c++){switch(a.charCodeAt(c)){case 34:r="&quot;";break;case 38:r="&amp;";break;case 39:r="&#39;";break;case 60:r="&lt;";break;case 62:r="&gt;";break;default:continue}i!==c&&(s+=a.substring(i,c)),i=c+1,s+=r}return i!==c?s+a.substring(i,c):s})))}}}));
